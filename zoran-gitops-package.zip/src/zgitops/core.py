class ZoranGitOps:
    def plan(self, change):
        return f"Plan: {change}"
    def apply(self, change):
        return f"Applied: {change}"
