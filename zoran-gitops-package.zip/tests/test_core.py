from zgitops.core import ZoranGitOps
def test_plan_apply():
    g = ZoranGitOps()
    assert "Plan:" in g.plan("update")
    assert "Applied:" in g.apply("update")
